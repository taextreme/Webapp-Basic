package io.muzoo.ooc.webapp.basic.servlets;

public interface Routable {

    String getPattern();

}
